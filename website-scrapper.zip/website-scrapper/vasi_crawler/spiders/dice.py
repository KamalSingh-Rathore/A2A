import json
import logging

import scrapy

from .util import extract_salary, extract_job_type, extract_desc
from ..helper import clean_value
from ..items import JobItem

logging.getLogger().setLevel("INFO")


class Dice(scrapy.Spider):
    name = "dice"
    custom_settings = {"DOWNLOAD_DELAY": 2}

    def start_requests(self):
        for page_no in range(1, 10):
            url = f"https://job-search-api.svc.dhigroupinc.com/v1/dice/jobs/search?locationPrecision=Country&latitude=37.09024&longitude=-95.712891&countryCode2=US&radius=30&radiusUnit=mi&page={page_no}&pageSize=100&facets=employmentType%7CpostedDate%7CworkFromHomeAvailability%7CemployerType%7CeasyApply%7CisRemote&filters.postedDate=ONE&fields=id%7CjobId%7Csummary%7Ctitle%7CpostedDate%7CjobLocation.displayName%7CdetailsPageUrl%7Csalary%7CclientBrandId%7CcompanyPageUrl%7CcompanyLogoUrl%7CpositionId%7CcompanyName%7CemploymentType%7CisHighlighted%7Cscore%7CeasyApply%7CemployerType%7CworkFromHomeAvailability%7CisRemote&culture=en&recommendations=true&interactionId=0&fj=true&includeRemote=true"

            yield scrapy.Request(
                url,
                callback=self.parse,
                headers={"x-api-key": "1YAt0R9wBg4WfsF9VB2778F5CHLAPMVW3WAZcKd8"},
            )

    def parse(self, response, **kwargs):
        resp = json.loads(response.text)
        for job in resp["data"]:
            url = job["detailsPageUrl"]
            if "https://www.dice.com/apply-redirect" in url:
                continue

            headers = {
                "accept": "application/json, text/plain, */*",
                "accept-language": "en-US,en;q=0.9,ta;q=0.8",
                "origin": "https://www.dice.com",
                "priority": "u=1, i",
                "referer": "https://www.dice.com/",
                "sec-ch-ua": '"Chromium";v="128", "Not;A=Brand";v="24", "Google Chrome";v="128"',
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": '"Linux"',
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "cross-site",
                "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
                "x-api-key": "1YAt0R9wBg4WfsF9VB2778F5CHLAPMVW3WAZcKd8"
            }
            yield scrapy.Request(url, headers=headers, callback=self.job_parse, dont_filter=False)

    def job_parse(self, response):
        job_item = JobItem()

        try:
            # title (required field)
            job_item["title"] = clean_value(
                response.xpath('//h1[@data-cy="jobTitle"]//text()').get(),
                required=True,
                title=False
            )

            # company name (required field)
            job_item["company_name"] = clean_value(
                response.xpath('//*[contains(@data-cy, "companyName")]//text()').get(),
                required=True,
                title=False
            )

            # job description
            desc_nodes = response.xpath('//*[@id = "jobDescription"]//node()').getall()
            job_item["desc"] = extract_desc(desc_nodes)

            # other static information
            job_item["externalLink"] = response.request.url
            job_item["src"] = "dice"
            job_item["country"] = "United States"

            # job type
            job_type_text = clean_value(
                response.xpath('//*[@data-cy = "employmentDetails"]//text()').get(),
                required=False
            )
            job_item["job_type"] = extract_job_type(job_type_text)

            # job skills
            job_item["job_skills"] = response.xpath('//*[@data-cy = "skillsList"]//text()').getall()

            # location
            job_item["city"] = response.xpath('//*[@data-cy = "locationDetails"]//text()').getall()

            # salary
            salary_text = response.xpath('//*[@data-cy = "payDetails"]//text()').get()

            if salary_text:
                job_item["salary"] = extract_salary(salary_text)

            logging.info("\n")

        except KeyError as e:
            logging.exception(f"EXCEPTION IN URL {response.request.url}")
            logging.exception(e)
            # TODO Handle reporting

        yield job_item

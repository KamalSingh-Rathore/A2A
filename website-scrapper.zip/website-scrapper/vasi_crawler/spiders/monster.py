import json
import logging

import scrapy

from scrapy import Spider
from scrapy.settings import Settings

from ..helper import clean_value, normalize_salary
from ..items import JobItem

logging.getLogger().setLevel("INFO")


class Monster(Spider):

    name = "monster"
    base_url = "https://www.monsterindia.com/"

    custom_settings = {"DOWNLOAD_DELAY": 2, "CONCURRENT_REQUESTS": 2}
    settings = Settings()

    industry_urls = [
        "https://www.monsterindia.com/search/it-computers-hardware-networking-jobs",
        "https://www.monsterindia.com/search/it-computers-software-jobs",
        "https://www.monsterindia.com/search/ites-bpo-jobs",
        "https://www.monsterindia.com/search/kpo-research-analytics-jobs",
        "https://www.monsterindia.com/search/telecom-jobs",
        "https://www.monsterindia.com/search/isp-jobs",
        "https://www.monsterindia.com/search/hotels-hospitality-restaurant-jobs",
        "https://www.monsterindia.com/search/airlines-aviation-aerospace-jobs",
        "https://www.monsterindia.com/search/travel-tourism-jobs",
        "https://www.monsterindia.com/search/consulting-advisory-services-jobs",
        "https://www.monsterindia.com/search/recruitment-staffing-rpo-jobs",
        "https://www.monsterindia.com/search/advertising-pr-events-jobs",
        "https://www.monsterindia.com/search/facility-management-jobs",
        "https://www.monsterindia.com/search/public-relations-jobs",
        "https://www.monsterindia.com/search/legal-law-firm-jobs",
        "https://www.monsterindia.com/search/customer-service-jobs",
        "https://www.monsterindia.com/search/law-enforcement-security-services-jobs",
        "https://www.monsterindia.com/search/entertainment-media-publishing-jobs",
        "https://www.monsterindia.com/search/environmental-service-jobs",
        "https://www.monsterindia.com/search/market-research-jobs",
        "https://www.monsterindia.com/search/social-media-jobs",
        "https://www.monsterindia.com/search/education-e-learning-jobs",
        "https://www.monsterindia.com/search/engineering-design-jobs",
        "https://www.monsterindia.com/search/automotive-auto-ancillaries-jobs",
        "https://www.monsterindia.com/search/machinery-equipment-mfg-jobs",
        "https://www.monsterindia.com/search/electrical-switchgears-jobs",
        "https://www.monsterindia.com/search/chemicals-petrochemicals-jobs",
        "https://www.monsterindia.com/search/metals-mining-jobs",
        "https://www.monsterindia.com/search/non-ferrous-metals-jobs",
        "https://www.monsterindia.com/search/escalators-elevators-jobs",
        "https://www.monsterindia.com/search/consumer-electronics-durables-appliances-jobs",
        "https://www.monsterindia.com/search/electrical-switchgears-jobs",
        "https://www.monsterindia.com/search/heat-ventilation-air-conditioning-jobs",
        "https://www.monsterindia.com/search/semiconductor-semiconductor-manufacturing-jobs",
        "https://www.monsterindia.com/search/glass-jobs",
        "https://www.monsterindia.com/search/iron-steel-jobs",
        "https://www.monsterindia.com/search/plastic-rubber-jobs",
        "https://www.monsterindia.com/search/electronics-manufacturing-jobs",
        "https://www.monsterindia.com/search/paints-jobs",
        "https://www.monsterindia.com/search/paper-jobs",
        "https://www.monsterindia.com/search/printing-packaging-jobs",
        "https://www.monsterindia.com/search/textiles-yarn-fabrics-garments-jobs",
        "https://www.monsterindia.com/search/tyres-jobs",
        "https://www.monsterindia.com/search/wood-jobs",
        "https://www.monsterindia.com/search/leather-jobs",
        "https://www.monsterindia.com/search/banking-accounting-financial-services-jobs",
        "https://www.monsterindia.com/search/insurance-jobs",
        "https://www.monsterindia.com/search/financial-markets-jobs",
        "https://www.monsterindia.com/search/fmcg-jobs",
        "https://www.monsterindia.com/search/retailing-jobs",
        "https://www.monsterindia.com/search/internet-e-commerce-jobs",
        "https://www.monsterindia.com/search/general-trading-import-export-jobs",
        "https://www.monsterindia.com/search/food-packaged-food-jobs",
        "https://www.monsterindia.com/search/beverages-liquor-jobs",
        "https://www.monsterindia.com/search/real-estate-jobs",
        "https://www.monsterindia.com/search/architecture-interior-design-jobs",
        "https://www.monsterindia.com/search/construction-engineering-jobs",
        "https://www.monsterindia.com/search/cement-concrete-readymix-jobs",
        "https://www.monsterindia.com/search/engineering-procurement-construction-jobs",
        "https://www.monsterindia.com/search/ceramics-sanitary-ware-jobs",
        "https://www.monsterindia.com/search/Office-equipment-automation-jobs",
        "https://www.monsterindia.com/search/railways-speciality-infrastructure-jobs",
        "https://www.monsterindia.com/search/power-energy-jobs",
        "https://www.monsterindia.com/search/alternate-energy-jobs",
        "https://www.monsterindia.com/search/oil-gas-petroleum-jobs",
        "https://www.monsterindia.com/search/hospitals-healthcare-hiagnostics-jobs",
        "https://www.monsterindia.com/search/pharmaceutical-jobs",
        "https://www.monsterindia.com/search/medical-transcription-jobs",
        "https://www.monsterindia.com/search/bio-technology-life-sciences-jobs",
        "https://www.monsterindia.com/search/shipping-marine-services-jobs",
        "https://www.monsterindia.com/search/courier-freight-transportation-jobs",
        "https://www.monsterindia.com/search/maritime-transportation-jobs",
        "https://www.monsterindia.com/search/agriculture-dairy-forestry-fishing-jobs",
        "https://www.monsterindia.com/search/fertilizer-pesticides-jobs",
        "https://www.monsterindia.com/search/sugar-jobs",
        "https://www.monsterindia.com/search/fashion-apparels-jobs",
        "https://www.monsterindia.com/search/wellness-fitness-sports-jobs",
        "https://www.monsterindia.com/search/gems-Jewellery-jobs",
        "https://www.monsterindia.com/search/ngo-social-services-jobs",
        "https://www.monsterindia.com/search/government-psu-defence-jobs",
    ]

    def start_requests(self):

        for industry_url in self.industry_urls:
            industry_url = industry_url.split("/")[-1]
            industry_url = industry_url.split("-")[:-1]
            industry_url = ",".join(industry_url)
            industry_url = (
                "https://www.monsterindia.com/middleware/jobsearch?sort=2&limit=100&query="
                + industry_url
            )

            yield scrapy.Request(
                industry_url,
                callback=self.parse,
                dont_filter=True,
            )

    def parse(self, response):
        data = json.loads(response.text)

        for job in data["jobSearchResponse"]["data"]:
            if job.get("id"):
                job_link = (
                    f"https://www.monsterindia.com/middleware/jobdetail/{job['id']}"
                )

            # Check if job is not an ad
            if "seoJdUrl" in job:
                yield scrapy.Request(
                    job_link,
                    callback=self.job_parse,
                    dont_filter=False,
                    meta={
                        "external_url": job["seoJdUrl"],
                    },
                )

    def job_parse(self, response):
        data = json.loads(response.body)

        try:
            each = data["jobDetailResponse"]
        except KeyError as e:
            logging.exception(f"EXCEPTION IN URL {response.request.url}")
            logging.exception(e)
        else:
            job_item = JobItem()

            try:
                job_item["title"] = clean_value(each["title"], required=True)
                job_item["company_name"] = clean_value(
                    each["company"]["name"], required=True
                )
                job_item["desc"] = clean_value(each["description"], required=True)
                job_item["externalLink"] = (
                    "https://www.monsterindia.com/search"
                    + response.meta["external_url"]
                )

                if "****" in job_item["company_name"]:
                    raise ValueError("COMPANY NAME NOT PRESENT")
            except KeyError as e:
                logging.exception(f"EXCEPTION IN URL {response.request.url}")
                logging.exception(e)
                # TODO Handle reporting
                # IMPORTANT - skip if above values not present
            except ValueError:
                logging.warning(f"NO COMPANY NAME {response.request.url}")
            else:
                if each.get("itSkills"):
                    job_item["job_skills"] = [x["text"] for x in each.get("itSkills")]
                else:
                    job_item["job_skills"] = []

                if each.get("skills"):
                    for x in each.get("skills"):
                        if "text" in x:
                            job_item["job_skills"].append(x["text"])

                job_item["src"] = "monster"
                job_item["country"] = "India"
                if each.get("roles"):
                    job_item["role"] = each.get("roles")[0]
                if each.get("industries"):
                    job_item["industry"] = each.get("industries")[0]
                if each.get("jobTypes"):
                    job_item["job_type"] = each.get("jobTypes")[0]

                job_item["experience"] = {
                    "min": each.get("minimumExperience")["years"],
                    "max": each.get("maximumExperience")["years"],
                }

                job_item["city"] = []
                if each.get("locations"):
                    for location in each.get("locations"):
                        job_item["city"] += [
                            clean_value(x) for x in location["city"].split("/")
                        ]

                try:
                    job_item["salary"] = {
                        "min": normalize_salary(each["minimumSalary"]["absoluteValue"]),
                        "max": normalize_salary(each["maximumSalary"]["absoluteValue"]),
                        "currency": "INR",
                    }
                except KeyError:
                    job_item["salary"] = {
                        "min": "",
                        "max": "",
                    }

                if each.get("locations")[0]["country"].lower() != "india":
                    job_item["salary"]["currency"] = ""

                logging.info("\n")
                logging.info("\n\n")

                yield job_item

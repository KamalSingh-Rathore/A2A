import logging
import math
import re

import scrapy

from bs4 import BeautifulSoup
from scrapy import Spider
from scrapy.settings import Settings

from ..helper import clean_value, normalize_salary
from ..items import JobItem

logging.getLogger().setLevel("INFO")


class Times(Spider):

    name = "timesjobs"

    custom_settings = {"DOWNLOAD_DELAY": 1, "CONCURRENT_REQUESTS": 2}
    settings = Settings()

    def start_requests(self):
        url = "https://www.timesjobs.com/candidate/job-search.html?from=submit&actualTxtKeywords="
        skills = ["*"]
        total_jobs = 5

        skills = [s.replace("+", "0PLUS0") for s in skills]
        skills = [s.replace(" ", "%20") for s in skills]
        skills = ",".join(skills)

        if False:
            link = ""
            yield scrapy.Request(
                link,
                callback=self.job_parse,
                dont_filter=True,
            )
        else:
            for location in self.settings.get("INDIA_LOCATIONS"):
                job_item_location = "%20,".join([location])

                final_url = (
                    url
                    + skills
                    + "&searchBy=0&rdoOperator=OR&searchType=personalizedSearch&txtLocation="
                    + job_item_location
                    + "&luceneResultSize=25&postWeek=60&txtKeywords="
                    + skills
                    + "&pDate=I&sequence="
                )

                for index in range(1, total_jobs + 1):
                    final_url_ = final_url + str(index) + "&startPage=1"
                    print(final_url_)
                    yield scrapy.Request(
                        final_url_,
                        callback=self.parse,
                        dont_filter=True,
                    )

    def parse(self, response):
        soup = BeautifulSoup(response.text, "html.parser")

        for div in soup.find_all("li", attrs={"class": "clearfix job-bx wht-shd-bx"}):
            link = div.find("a")["href"]
            link = link.replace(" ", "%20")

            yield scrapy.Request(
                link,
                callback=self.job_parse,
                dont_filter=True,
            )

    def job_parse(self, response):
        job_item = JobItem()

        try:
            job_item["title"] = clean_value(
                response.xpath('//h1[@class="jd-job-title"]/text()').extract()[-1],
                required=True,
            )

            job_item["company_name"] = clean_value(
                response.xpath(
                    '//div[@class="jd-header wht-shd-bx"]/h2/text()'
                ).extract_first(),
                required=True,
            )

            job_item["desc"] = clean_value(
                response.xpath(
                    '//div[@class="jd-desc job-description-main"]'
                ).extract_first(),
                required=True,
            )
            job_item["desc"] = job_item["desc"].replace("<h3>Job Description</h3>", "")

            job_item["externalLink"] = response.request.url
        except Exception as e:
            logging.exception(e)
            # TODO Handle reporting
        else:
            job_item["job_skills"] = response.xpath(
                '//div[@class="jd-sec job-skills clearfix"]/div/span/a/text()'
            ).extract()
            job_item["job_skills"] = [clean_value(x) for x in job_item["job_skills"]]

            job_item["src"] = "timesjobs"

            job_item["role"] = response.xpath(
                '//div[@class="job-basic-info"]/ul/li[1]/span/text()'
            ).extract_first()

            job_item["country"] = "India"

            # Experinece
            experience = response.xpath(
                '//ul[@class="top-jd-dtl clearfix"]/li[1]/text()[2]'
            ).extract_first()
            experience = experience.strip()
            experience = re.findall("^.*\d", experience)
            job_item["experience"] = {}
            if experience:
                experience = experience[0].split("to")
                if len(experience) == 2:
                    job_item["experience"] = {
                        "min": int(experience[0].strip()),
                        "max": int(experience[1].strip()),
                    }

            # Location
            job_item["city"] = []
            cities = response.xpath(
                '//ul[@class="top-jd-dtl clearfix"]/li[3]/text()'
            ).extract_first()
            if cities:
                for x in cities.split(","):
                    city = x.strip()
                    city = city.split("(")[0].strip()
                    job_item["city"].append(city)

            # Salary
            job_item["salary"] = {
                "min": "",
                "max": "",
                "currency": "",
            }

            salary = response.xpath(
                '//ul[@class="top-jd-dtl clearfix"]/li[2]/text()'
            ).extract_first()

            if "-" in salary:
                salary = salary.split("-")
                job_item["salary"]["min"] = math.floor(
                    float(salary[0].split()[-1].strip()) * 10 / 10
                )
                job_item["salary"]["max"] = math.floor(
                    float(salary[1].split()[0].strip()) * 10 / 10
                )
                job_item["salary"]["currency"] = "INR"

            logging.info("\n")
            logging.info("\n\n")

            yield job_item

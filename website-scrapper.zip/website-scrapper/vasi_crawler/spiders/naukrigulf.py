import scrapy

from scrapy import Spider


class NaukriGulf(Spider):

    name = "naukrigulf"
    base_url = "https://www.naukrigulf.com/"

    urls = [
        "https://www.naukrigulf.com/jobs-in-uae",
        "https://www.naukrigulf.com/jobs-in-saudi-arabia",
        "https://www.naukrigulf.com/jobs-in-oman",
        "https://www.naukrigulf.com/jobs-in-kuwait",
        "https://www.naukrigulf.com/jobs-in-qatar",
        "https://www.naukrigulf.com/jobs-in-bahrain",
    ]

    def start_requests(self):

        for url in self.urls:

            yield scrapy.Request(
                self.url,
                callback=self.parse,
                dont_filter=True,
                meta={"skills": "*", "total_jobs": "3", "location": "arab"},
            )

    def parse(self, response):
        total_jobs = 2

        skills = response.meta.get("skills", None)
        total_jobs = response.meta.get("total_jobs", None)
        location = response.meta.get("location", None)

        total_jobs = int(total_jobs.strip()) + 1 if total_jobs else None

        links = []
        skills = []
        final_url = ""

        if skills:
            skills = skills.split(",")
            skills = [s.strip() for s in skills]
            skills = [s.replace(" ", "-") for s in skills]
            skills = [s.replace("+", "-plus") for s in skills]
            skills = "-".join(skills)

            if location:
                location.split(",")

            if len(location) == 0:
                final_url = self.base_url + skills + "-jobs"
            else:
                locations = "-".join(location)
                final_url = self.base_url + skills + "-jobs-in-" + locations
                print(final_url)
        else:
            return "Error: No skills field provided. Please specify an skills."

        options = Options()
        if os.environ.get("ENVIRONMENT") != "DEV":
            options.add_argument("--headless")
            options.add_argument("--no-sandbox")
            options.add_argument("--disable-gpu")
            chrome_path = "/home/ubuntu/ai-data/chromedriver"
        else:
            chrome_path = "/home/iso-6/Workspace/koli/ai-data/chromedriver"

        driver = webdriver.Chrome(executable_path=chrome_path, chrome_options=options)

        # html = driver.get(skill_url)
        # html = driver.page_source

        # soup = BeautifulSoup(driver.page_source, 'html.parser')
        # for div in soup.find_all('li', attrs={'class':'desig'}):
        #   link = div.find('a')['href']
        # link = link.replace(' ','%20')
        #  links.append(link)

        # text = soup.body.findAll(text=re.compile('^Apply to '))
        # total_jobs = re.findall(r'\d+',str(text))
        # total_jobs = int(total_jobs[0])

        print(type(total_jobs), total_jobs)

        # if int(total_jobs/50)+1 > 5:
        #   total_jobs = 5
        # else:
        #   total_jobs = int(total_jobs/50)+1
        html = driver.get(final_url)
        print(final_url)
        soup = BeautifulSoup(driver.page_source, "html.parser")

        for div in soup.find_all("li", attrs={"class": "desig"}):

            link = div.find("a")["href"]
            print(link)
            # link = link.replace(' ','%20')
            links.append(link)

        for i in range(2, total_jobs):  #

            # if len(location) == 0:
            #   final_url_ = base_url+skills+'-jobs-'+str(i)
            # else:
            #   skill_url = base_url+skills+"-jobs-in-"+locations+"-"+str(i)

            html = driver.get(final_url + "-" + str(i))
            print(final_url + str(i))
            soup = BeautifulSoup(driver.page_source, "html.parser")
            for div in soup.find_all("li", attrs={"class": "desig"}):
                link = div.find("a")["href"]
                # link = link.replace(' ','%20')
                links.append(link)

        # print(skill_url)
        # print(html)

        # print(soup.prettify())
        dic = {"link": links}
        print("nukri ", len(links))
        driver.quit()
        return jsonify(dic)

import json
import logging

import scrapy
from scrapy import Spider
from scrapy.settings import Settings

from ..helper import clean_value, normalize_salary
from ..items import JobItem

logging.getLogger().setLevel("INFO")


class Naukri(Spider):
    name = "naukri"
    base_url = "https://www.naukri.com/"

    custom_settings = {"DOWNLOAD_DELAY": 2, "CONCURRENT_REQUESTS": 2}
    settings = Settings()

    def start_requests(self):

        headers = {
            "appid": "109",
            "cache-control": "no-cache",
            "clientid": "d3skt0p",
            "referer": "https://www.naukri.com/jobs-in-delhi-ncr",
            "nkparam": "AYq1LUE/itM9S1kHG3vXRUgFhdDFCu78xdlS32dJIbqoDflsCuSaJtApeRoVuVze/uDIANbpuaniMO6Cl1cVbQ==",
            "sec-ch-ua": 'Chromium";v="128", "Not;A=Brand";v="24", "Google Chrome";v="128',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "systemid": "109",
            "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36",
        }

        for location in self.settings.get("INDIA_LOCATIONS"):
            url = f"https://www.naukri.com/jobapi/v3/search?noOfResults=100&urlType=search_by_location&searchType=adv&location={location}&src=jobsearchDesk"

            yield scrapy.Request(
                url,
                callback=self.parse_urls,
                dont_filter=True,
                headers=headers,
            )

    def parse_urls(self, response, **kwargs):
        data = json.loads(response.body)

        for each in data["jobDetails"]:
            external_url = "https://www.naukri.com" + each["jdURL"]

            headers = {
                "accept": "application/json",
                # "accept-encoding": "gzip, deflate, br",
                "accept-language": "en-IN,en-GB;q=0.9,en-US;q=0.8,en;q=0.7",
                "appid": "121",
                "cache-control": "no-cache",
                "clientid": "d3skt0p",
                "nkparam": "AYq1LUE/itM9S1kHG3vXRUgFhdDFCu78xdlS32dJIbqoDflsCuSaJtApeRoVuVze/uDIANbpuaniMO6Cl1cVbQ==",
                "sec-ch-ua": 'Chromium";v="128", "Not;A=Brand";v="24", "Google Chrome";v="128',
                "referer": external_url,
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-origin",
                "systemid": "Naukri",
                "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36",
            }

            url = f"https://www.naukri.com/jobapi/v4/job/{each['jobId']}"

            yield scrapy.Request(
                url,
                callback=self.parse,
                dont_filter=False,
                headers=headers,
                meta={"external_url": external_url},
            )

    def parse(self, response, **kwargs):
        data = json.loads(response.body.decode("utf-8"))

        try:
            each = data["jobDetails"]
        except KeyError as e:
            logging.exception(f"EXCEPTION IN URL {response.request.url}")
            logging.exception(e)
        else:
            job_item = JobItem()

            try:
                job_item["title"] = clean_value(each["title"], required=True)
                job_item["company_name"] = clean_value(
                    each["companyDetail"]["name"], required=True
                )
                job_item["desc"] = clean_value(each["description"], required=True)
                job_item["externalLink"] = response.meta["external_url"]
            except KeyError as e:
                logging.exception(f"EXCEPTION IN URL {response.request.url}")
                logging.exception(e)
                # TODO Handle reporting
                # IMPORTANT - skip if above values not present
            else:
                if each.get("keySkills"):
                    job_item["job_skills"] = [
                        x["label"] for x in each.get("keySkills")["other"]
                    ]
                else:
                    job_item["job_skills"] = []

                job_item["src"] = "naukri"
                job_item["country"] = "India"
                job_item["role"] = each.get("jobRole", "")
                job_item["industry"] = each.get("industry", "")
                job_item["job_type"] = each.get("jobType", "")

                job_item["experience"] = {
                    "min": each.get("minimumExperience", ""),
                    "max": each.get("maximumExperience", ""),
                }

                job_item["city"] = []
                if each.get("locations"):
                    for location in each.get("locations"):
                        job_item["city"].append(clean_value(location["label"]))

                job_item["salary"] = {}
                if each.get("salaryDetail"):

                    if each.get("salaryDetail")["hideSalary"]:
                        job_item["salary"] = {
                            "min": "",
                            "max": "",
                            "currency": "",
                        }
                    else:
                        try:
                            job_item["salary"] = {
                                "min": normalize_salary(
                                    each["salaryDetail"].get("minimumSalary")
                                ),
                                "max": normalize_salary(
                                    each["salaryDetail"].get("maximumSalary")
                                ),
                                "currency": each["salaryDetail"].get("currency"),
                            }
                        except Exception as e:
                            job_item["salary"] = {
                                "min": "",
                                "max": "",
                                "currency": "",
                            }
                            logging.info(e)

                logging.info("\n")
                logging.info("\n\n")

                yield job_item

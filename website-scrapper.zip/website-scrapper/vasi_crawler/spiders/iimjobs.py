import logging
import re

import scrapy

from scrapy import Spider
from scrapy.settings import Settings

from ..helper import clean_value
from ..items import JobItem

logging.getLogger().setLevel("INFO")


class IIMJobs(Spider):

    name = "iimjobs"
    base_url = "https://www.iimjobs.com/"

    custom_settings = {"DOWNLOAD_DELAY": 2, "CONCURRENT_REQUESTS": 2}
    settings = Settings()

    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Host": "www.iimjobs.com",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36",
    }

    industry_urls = [
        "https://www.iimjobs.com/c/filter/banking-finance-jobs-in-any-location-13-0-0-100-{}.html",
        "https://www.iimjobs.com/c/filter/it-systems-jobs-in-any-location-15-0-0-100-{}.html",
        "https://www.iimjobs.com/c/filter/sales-marketing-jobs-in-any-location-14-0-0-100-{}.html",
        "https://www.iimjobs.com/c/filter/consulting-general-mgmt-jobs-in-any-location-16-0-0-100-{}.html",
        "https://www.iimjobs.com/c/filter/hr-ir-jobs-in-any-location-17-0-0-100-{}.html",
        "https://www.iimjobs.com/c/filter/scm-operations-jobs-in-any-location-19-0-0-100-{}.html",
        "https://www.iimjobs.com/c/filter/legal-jobs-in-any-location-21-0-0-100-{}.html",
        "https://www.iimjobs.com/c/filter/bpo-jobs-in-any-location-22-0-0-100-{}.html",
    ]

    def start_requests(self):

        for industry_url in self.industry_urls:
            for index in range(1, 6):
                industry_url = industry_url.format(index)

                yield scrapy.Request(
                    industry_url,
                    headers=self.headers,
                    callback=self.parse,
                    dont_filter=True,
                )

    def parse(self, response):
        job_urls = response.xpath('//a[@class="mrmob5 hidden-xs"]/@href').extract()

        for job_url in job_urls:
            yield scrapy.Request(
                job_url,
                headers=self.headers,
                callback=self.parse_jobs,
                dont_filter=True,
            )

    def parse_jobs(self, response):
        job_item = JobItem()

        try:
            job_item["title"] = clean_value(
                response.xpath(
                    '//div[contains(@class, "info")]/h3/b/text()'
                ).extract_first(),
                required=True,
            )

            company_temp_selectors = response.xpath('//div[@id="jobrecinfo"]/span[1]')
            for each in company_temp_selectors:
                if (
                    each.xpath("./small/text()")
                    and "posted by" in each.extract().lower()
                ):
                    company_temp = each.xpath("./text()").extract()[-1].strip()
                    if " at " in company_temp.lower():
                        job_item["company_name"] = clean_value(
                            company_temp.split(" at ")[-1].title(), required=True
                        )
                        break

            job_item["desc"] = clean_value(
                response.xpath(
                    '//div[contains(@class, "job-description")]'
                ).extract_first(),
                required=True,
            )
            job_item["desc"] = re.sub(
                "(?m)<script>(.*?)</script>", "", job_item["desc"], flags=re.DOTALL
            )

            job_item["externalLink"] = response.request.url
        except Exception as e:
            logging.exception(e)
            # TODO Handle reporting
        else:
            job_item["src"] = "iimjobs"
            job_item["country"] = "India"

            try:
                job_item["job_skills"] = response.xpath(
                    '//ul[contains(@class, "list-inline tags")]/li/a/text()'
                ).extract()
                job_item["job_skills"] = [
                    clean_value(x.replace("#", "")) for x in job_item["job_skills"]
                ]
                job_item["job_skills"] = list(set(job_item["job_skills"]))
            except Exception as e:
                logging.exception(e)

            try:
                industry_temp_selectors = response.xpath(
                    '//div[@id="jobrecinfo"]/span[2]'
                )
                for each in industry_temp_selectors:
                    if (
                        each.xpath("./small/text()")
                        and "posted in"
                        in each.xpath("./small/text()").extract_first().lower()
                    ):
                        industry_temp = each.xpath("./a/text()").extract()[-1].strip()
                        job_item["industry"] = clean_value(industry_temp, required=True)

                        break
            except Exception as e:
                logging.exception(e)

            try:
                job_item["experience"] = {}
                reg = "\(\d+\-\d+\syrs\)"
                experience = re.findall(reg, job_item["title"])
                if experience:
                    experience = experience[0]
                    experience = experience.split()[0]
                    experience = experience.replace("(", "")
                    job_item["experience"] = {
                        "min": experience.split("-")[0],
                        "max": experience.split("-")[1],
                    }
            except Exception as e:
                logging.exception(e)

            # Location
            job_item["city"] = []
            cities = response.xpath(
                '//span[contains(@class, "jobloc")]/a/text()'
            ).extract_first()
            if cities:
                cities = cities.strip()
                for x in cities.split("/"):
                    city = x.strip()
                    job_item["city"].append(city)

            logging.info("\n")
            logging.info("\n\n")

            yield job_item

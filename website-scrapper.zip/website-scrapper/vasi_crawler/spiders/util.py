import re
from ..items import Salary
from ..helper import clean_value


def extract_digit_sequences(text):
    digit_sequences = re.findall(r'\d+(?:[.,]\d+)*', text)
    cleaned_sequences = [(sequence.replace(',', '')) for sequence in digit_sequences]
    out_sequences = [float(seq) if "." in seq else int(seq) for seq in cleaned_sequences]

    return out_sequences


def extract_salary(text):
    salary = Salary()
    if ("$" or "USD") in text:
        salary["currency"] = "USD"
    else:
        salary["currency"] = ""

    digit_seq = extract_digit_sequences(text)

    if digit_seq:
        if "month" in text:
            salary["min"] = 12 * min(digit_seq)
            salary["max"] = 12 * max(digit_seq)

        elif ("hour" and "week") not in text:
            salary["min"] = min(digit_seq)
            salary["max"] = max(digit_seq)

    return salary

job_types = {
    "contract": "contract",
    "full time": "fulltime",
    "part time": "parttime",
    "freelance": "freelance",
    "intern": "internship"
}

def extract_job_type(job_type_text):

    for key, value in job_types.items():
        if key in job_type_text.lower():
            return value


def extract_desc(desc_nodes):

    cleaned_nodes = [clean_value(node) for node in desc_nodes]
    desc = " ".join(cleaned_nodes)
    return desc



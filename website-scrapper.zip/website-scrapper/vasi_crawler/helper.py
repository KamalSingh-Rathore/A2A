import math
import re
import requests


def clean_value(value, required=False, title=True):
    value = value.strip() if value else None
    # value = value.strip()

    if required and not value:
        raise ValueError("Required value does not exist")

    if value and title:
        value = value.title()

    return value

def send_to_server(data):
    url = "https://test-api.vasitum.com/v2/external_job"

    resp = requests.post(url, json=data)

    if resp.status_code != 200:
        # TODO Handle reporting
        print("\n\nError sending to db\n\n")

    return resp


def normalize_salary(salary):
    salary = int(re.sub("[^0-9]", "", str(salary))) / 100000
    salary = math.floor(salary * 10) / 10

    return salary



# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

from scrapy.item import Item, Field


class Salary(Item):
    min = Field()
    max = Field()
    currency = Field()


class JobItem(Item):
    title = Field()
    company_name = Field()
    desc = Field()
    externalLink = Field()
    job_skills = Field()
    src = Field()
    country = Field()
    role = Field()
    industry = Field()
    job_type = Field()
    city = Field()
    experience = Field()  # {'min': 1, 'max': 3}
    salary = Field()  # {'min': 2.0, 'max': 3.0, 'currency': 'INR'}
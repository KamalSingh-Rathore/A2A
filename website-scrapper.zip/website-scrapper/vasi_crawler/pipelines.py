# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import requests
import logging

from itemadapter import ItemAdapter
from scrapy.exceptions import DropItem

from .settings import DUMP_URL


logging.getLogger().setLevel("INFO")


class VasiCrawlerPipeline:
    def process_item(self, item, spider):
        data = ItemAdapter(item)

        resp = requests.post(DUMP_URL, json=data.asdict())
        logging.info(resp.text)

        if resp.status_code != 200:
            raise DropItem("\n\nError sending to API\n\n")
            # TODO Handle reporting
            print("\n\nError sending to API\n\n")
        else:
            return item

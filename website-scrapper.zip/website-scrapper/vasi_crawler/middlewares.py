# Define here the models for your spider middleware
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/spider-middleware.html

import requests
import traceback
from scrapy import signals

# useful for handling different item types with a single interface
from itemadapter import is_item, ItemAdapter

# Replace this with your actual Slack webhook URL
SLACK_WEBHOOK_URL = "https://hooks.slack.com/services/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"
TEAMS_WEBHOOK_URL = "https://vasitum.webhook.office.com/webhookb2/f7061264-0d39-4324-8275-0c2438c7e0fa@9193a4fb-b618-482e-a019-0b049a2d94e8/IncomingWebhook/58f6fdf2456b46a5aa5032eecbb9b3e0/7abca129-4d5a-42c6-9dbd-e5d5281f74e0/V2gXS_C9NOoUB9wl3TSUuBOC4qVLsI2FR-C7sa8OSf7KA1"

def send_slack_notification(message):
    """Send an error notification to Slack."""
    payload = {"text": message}
    try:
        requests.post(SLACK_WEBHOOK_URL, json=payload)
        requests.post(TEAMS_WEBHOOK_URL, json=payload)
    except Exception as e:
        print(f"Failed to send Slack notification: {e}")

class VasiCrawlerSpiderMiddleware:
    # Not all methods need to be defined. If a method is not defined,
    # scrapy acts as if the spider middleware does not modify the
    # passed objects.

    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_spider_input(self, response, spider):
        # Called for each response that goes through the spider
        # middleware and into the spider.

        # Should return None or raise an exception.
        return None

    def process_spider_output(self, response, result, spider):
        # Called with the results returned from the Spider, after
        # it has processed the response.

        # Must return an iterable of Request, or item objects.
        for i in result:
            yield i

    def process_spider_exception(self, response, exception, spider):
        """Send Slack notification when a spider exception occurs."""
        error_message = (
            f"*Scrapy Spider Exception in {spider.name}*\n"
            f"URL: {response.url if response else 'N/A'}\n"
            f"Error: ```{str(exception)}```\n"
            f"Traceback: ```{traceback.format_exc()}```"
        )
        send_slack_notification(error_message)
        return None  # Continue Scrapy’s default exception handling

    def process_start_requests(self, start_requests, spider):
        # Called with the start requests of the spider, and works
        # similarly to the process_spider_output() method, except
        # that it doesn’t have a response associated.

        # Must return only requests (not items).
        for r in start_requests:
            yield r

    def spider_opened(self, spider):
        spider.logger.info(f'Spider opened: {spider.name}')

class VasiCrawlerDownloaderMiddleware:
    # Not all methods need to be defined. If a method is not defined,
    # scrapy acts as if the downloader middleware does not modify the
    # passed objects.

    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_request(self, request, spider):
        # Called for each request that goes through the downloader
        # middleware.

        # Must either:
        # - return None: continue processing this request
        # - or return a Response object
        # - or return a Request object
        # - or raise IgnoreRequest: process_exception() methods of
        #   installed downloader middleware will be called
        return None

    def process_response(self, request, response, spider):
        # Called with the response returned from the downloader.

        # Must either;
        # - return a Response object
        # - return a Request object
        # - or raise IgnoreRequest
        return response

    def process_exception(self, request, exception, spider):
        """Send Slack notification when a request fails."""
        error_message = (
            f"*Scrapy Request Exception in {spider.name}*\n"
            f"URL: {request.url}\n"
            f"Error: ```{str(exception)}```\n"
            f"Traceback: ```{traceback.format_exc()}```"
        )
        send_slack_notification(error_message)
        return None  # Continue Scrapy’s default exception handling

    def spider_opened(self, spider):
        spider.logger.info(f'Spider opened: {spider.name}')

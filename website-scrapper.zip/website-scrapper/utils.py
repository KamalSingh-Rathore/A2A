from linkedin_scraper import Person, actions

from constants import EMAIl, PASSWORD


def scrape_data_from_linkedin(linkedin_url, driver):
    person = Person(linkedin_url=linkedin_url, driver=driver, scrape=False)
    if not person.is_signed_in():
        actions.login(driver, email=EMAIl, password=PASSWORD)
    person.scrape()
    return person

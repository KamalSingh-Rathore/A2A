class Config(object):
    TESTING = False
    DEBUG = False


class DevConfig(Config):
    ENV = 'development'
    DEBUG = True
    DATABASE_URI = ("mongodb://admin:b96f9649-61e9-47e0-80c1-c279f5fba755@qa-mongodb.vasitum.com:27017/vasitum"
                    "?authSource=admin&readPreference=primary&directConnection=true&ssl=false")


class ProductionConfig(Config):
    ENV = 'production'
    DEBUG = False
    DATABASE_URI = 'mongodb://vasi:6d10c8f0-b3dd-4d4b-81b0-392f1c94086d@mongodb.vasitum.com:27017/new_vasitum'


class TestConfig(Config):
    ENV = 'development'
    DEBUG = True
    DATABASE_URI = ("mongodb://admin:b96f9649-61e9-47e0-80c1-c279f5fba755@qa-mongodb.vasitum.com:27017/vasitum"
                    "?authSource=admin&readPreference=primary&directConnection=true&ssl=false")


class LocalConfig(Config):
    ENV = 'local'
    DEBUG = True

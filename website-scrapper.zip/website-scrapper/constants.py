EMAIl = "sknn0509@gmail.com"
PASSWORD = "VasiutmPasswordForDummyAccount"
COOKIES = "AQEDAUYVT8cEOIkgAAABimlI3XgAAAGKjVVheE4APVnkaexAeJya4UpOsgvRESWN8qGIPKFkqlW0uDbDjkRYeOc2S6FV-Gn2t-nstwDPPEbOSTi1oLdrN-6cDgdDDxZKFel16gIj09BwnoI7tLKin-Jz"
